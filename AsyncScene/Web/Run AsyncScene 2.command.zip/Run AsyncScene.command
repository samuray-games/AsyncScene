#!/bin/bash
set -e

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WEB_DIR="$ROOT_DIR/Web"
TOOLS_DIR="$ROOT_DIR/tools"
LOG_DIR="$ROOT_DIR/AsyncSceneLogs"
LOGGER_JS="$TOOLS_DIR/logger.js"

mkdir -p "$LOG_DIR"

echo "▶ AsyncScene launcher"
echo "▶ Root: $ROOT_DIR"

echo "▶ Starting logger on :17321 ..."
if lsof -i :17321 >/dev/null 2>&1; then
  echo "  Logger already running"
else
  node "$LOGGER_JS" > "$LOG_DIR/logger.out.log" 2>&1 &
  echo "  Logger started (pid=$!)"
fi

sleep 0.3

echo "▶ Starting web server on :8080 ..."
cd "$WEB_DIR"

if lsof -i :8080 >/dev/null 2>&1; then
  echo "  Web server already running"
else
  python3 -m http.server 8080 >/dev/null 2>&1 &
  echo "  Web server started (pid=$!)"
fi

sleep 0.3

URL="http://localhost:8080/index.html?dev=1"
echo "▶ Opening browser: $URL"
open -n "$URL"

echo "▶ Done"
